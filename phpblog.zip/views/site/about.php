<?php

/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\widgets\LinkPager;
use yii\widgets\Calendario;
use yii\helpers\Url;
$this->title = 'Про мене';
$this->params['breadcrumbs'][] = $this->title;
?>
<!--main content start-->
<html>
</html>
<body>
<div class="content">
    <h1 style="color:white; text-align: center ;"><?= Html::encode($this->title) ?></h1>
    <div class="container" style="background:#241B0F;">
        <div class="row" style="margin-top:3%;">
            <div class="col-md-4">
                <img style="border:2px double black;" src="https://static.wixstatic.com/media/eeb346_263b62403d454b24b4fd23488d403ea7~mv2_d_2557_3780_s_4_2.jpg/v1/crop/x_0,y_260,w_2557,h_2556/fill/w_418,h_418,al_c,q_80,usm_0.66_1.00_0.01/eeb346_263b62403d454b24b4fd23488d403ea7~mv2_d_2557_3780_s_4_2.webp" alt="">
            </div>
            <div class="col-md-8">
            <ul style="font-size:26px;color:white;">
                <li  >Вчитель музичного мистецтва, художньої культури.</li>
                <li  >Категорія  - І. </li>
                <li  >Освіта вища Хмельницька гуманітарно-педагогічна академія</li>
                <li  >Педагогічний стаж 11 років.</li>
                <li  >Упорядник посібника "Скарбничка народної душі Поділля"</li>
            </ul>
            </div>
        </div>
        <div class="row" style="margin-top:3%;">
            <div class="col-md-1" ></div>
            <div class="col-md-10">
            <pre style="font-size:14px;color:white;background:#241B0F;border:none;">  
    Учитись важко, а учить ще важче,
Але не мусим зупинятись ми, 
Як дітям віддамо усе найкраще,
Тоді й самі сягнем нової висоти

    Кожен день я відкриваю двері класу і до мене звертають погляди мої учні,їх світлі очі: допитливі, добрі, оцінюючі. 
Вони багато чекають від мене. І я дарую їм щастя відкриття і спілкування.
    Я люблю свою роботу, своїх учнів. А вони – мене. І поки цей взаємозв’язок існує, я знаю для чого  живу на Землі</pre>
            </div>
            <div class="col-md-1" ></div>
        </div>
    </div>
</div>  
</body>

